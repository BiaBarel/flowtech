from core.crud_base import CrudBase
from core.database import Database
from core.validator import Validator

class Funcionario(CrudBase):
    table = "funcionario"
    primary_key = "funcionario_id"
    fields = [
        "nome",
        "CPF",
        "e_mail",
        "setor",
        "cargo",
        "salario",
        "turno",
        "senha",
        "telefone",
        "data_nascimento"
    ]

    def __init__(self, nome, CPF, e_mail, setor, cargo, salario, turno, senha, telefone, data_nascimento, funcionario_id=None):
        self.funcionario_id = funcionario_id
        self.nome = nome
        self.CPF = CPF
        self.e_mail = e_mail
        self.setor = setor
        self.cargo = cargo
        self.salario = salario
        self.turno = turno
        self.senha = senha
        self.telefone = telefone
        self.data_nascimento = data_nascimento

    @classmethod
    def autenticar(cls, email, senha):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = f"SELECT * FROM {cls.table} WHERE e_mail = %s AND senha = %s"
            cursor.execute(sql, (email, senha))
            return cursor.fetchone()
        finally:
            cursor.close()
            conexao.close()


    @classmethod
    def safe_delete(cls, funcionario_id):
        funcionario = cls.find_by_id(funcionario_id)
        if not funcionario:
            raise ValueError("funcionario não encontrado.")
        
        return super().delete(funcionario_id)
